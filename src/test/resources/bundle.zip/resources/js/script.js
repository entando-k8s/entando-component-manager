$(function () {

  $('.html').append($('<div>Hello world</div>'));

})();